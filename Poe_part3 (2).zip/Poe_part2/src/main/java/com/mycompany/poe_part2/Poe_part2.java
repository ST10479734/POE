/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe_part2;
    import javax.swing.*;
import java.util.Random;
/**
 *
 * @author RC_Student_lab
 */
public class Poe_part2 {
    // DefaultListModels to store messages
private static DefaultListModel<String> sendMessage = new DefaultListModel<>();
    private static DefaultListModel<String> recentlySentMessage = new DefaultListModel<>();
    private static DefaultListModel<String> discardedMessage = new DefaultListModel<>();
    
     // To generate random numbers
   private static Random random = new Random();
  

  
    public static void main(String[]args){
        
    // User login process
        Login objLogin = new Login();
        String firstName = JOptionPane.showInputDialog(null,"Enter firstname");
        String lastName = JOptionPane.showInputDialog(null,"Enter lastname");
        
        
       // Username validation loop 
       boolean isUserNameValid = false;
       while (!isUserNameValid){
    String UserName = JOptionPane.showInputDialog(null,"Enter username");
    
    if(objLogin.checkUserName(UserName)){
        JOptionPane.showMessageDialog(null,"Username successfully captured");
        isUserNameValid = true;
       // If username format is invalid, prompt user to retry 
    }else{
     JOptionPane.showMessageDialog(null,"User name is not correctly formatted please ensure that your user name contains an underscore and is no more than 5 characters in length try again");
    }
    {
        
        //Ensure phone number is in the correct format
       boolean isCellPhoneNumberValid = false;
       while (!isCellPhoneNumberValid){
    String CellPhoneNumber = JOptionPane.showInputDialog(null,"Enter Cellphone number");
    
    if(objLogin.cheackCellPhoneNumber(CellPhoneNumber)){
        JOptionPane.showMessageDialog(null,"Cell phone number succesfully added");
        isCellPhoneNumberValid = true;
       
    }else{
      JOptionPane.showMessageDialog(null,"Cell phone number incorrectly formatted or does not contain international code try again"); 
    }
       }
       
        // Password validation loop
       boolean isPasswordValid = false;
       while (!isPasswordValid){
    String Password = JOptionPane.showInputDialog( null, "Enter password");
    
     // Welcome message displayed upon successful login
    if(objLogin.cheackPassword(Password)){
        JOptionPane.showMessageDialog(null,"Welcome to quick chats"+ "_" + firstName +"_" + lastName +"_"+"it's great to see you");
    }
    
     // Main program loop with menu for different options
        while (true) {
            String[] options = {"Send Message", "Recently Sent Message","Discarded Message" ,"Stored Message" , "Search Message", "Delete Message", "Display Longest Message", "Read JSON File", "Quit"};
            int option = JOptionPane.showOptionDialog(null, "Choose Option", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (option) {
                case 0:
                    sendMessage();
                    break;
                case 1:
                    recentlySentMessage();
                    break;
                case 2:
                     discardedMessage();
                    break;
                case 3:
                     storedMessage();
                    break;
                case 4:
                    searchMessage();
                    break;
                case 5:
                    deleteMessage();
                    break;
                case 6:
                    displayLongestMessage();
                    break;
                case 7:
                    readJsonFile();
                    break;
                case 8:
                    JOptionPane.showMessageDialog(null, "Goodbye");
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }
    }
    }
       }
    }
    
    // Method to send messages
    private static void sendMessage(){                       
                        String numberofMessagesStr = JOptionPane.showInputDialog("How many messages would you like to send?");
                       int numberofMessages = Integer.parseInt(numberofMessagesStr);
                       for (int i = 0; i < numberofMessages; i++){
        String userMessage = JOptionPane.showInputDialog("Enter your message:");
        String recipientPhoneNumber = JOptionPane.showInputDialog("Enter recipients cellphone number");
        String[] messageOptions = {"Send", "Store","Discard"};
                               int messageOption = JOptionPane.showOptionDialog(null, "Choose an action for this message", "Message options",
                                       JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, messageOptions, messageOptions[0]);
                               
                               // Generate a unique message ID
                              String newMessageId = generateMessageId();
                                   String messageWithId = "ID:" + newMessageId + "recipient:"+ recipientPhoneNumber + " Message:" + userMessage;
                                   
                                    // Perform action based on the user's choice (send, store, discard)
                               switch (messageOption) {
                                   case 0:
                                   JOptionPane.showMessageDialog(null,"Message sent" );
                                   sendMessage .addElement(messageWithId);
                                   break;
                                   case 1:
                                       JOptionPane.showMessageDialog(null,"Message stored for later"  );
                                      recentlySentMessage.addElement(userMessage);
                                       break;
                                   case 2:
                                       JOptionPane.showMessageDialog(null, "Message discarded");
                                       discardedMessage.addElement(userMessage);
break;
default:
break;
                       }
                        }
}
        
// Method to display all recently sent messages
private static void recentlySentMessage(){
            if ( sendMessage.isEmpty()){
                            JOptionPane.showMessageDialog(null, "No messages sent");
                            }else{
                            StringBuilder messages = new StringBuilder("Sent Messages:\n");
                            for (int i = 0; i <  sendMessage.size(); i++) {
                messages.append( sendMessage.getElementAt(i)).append("\n");
            }
            JOptionPane.showMessageDialog(null, messages.toString());
                   
                                        }
            }
    // Method to display all recently stored Message
    private static void storedMessage() {
    if (recentlySentMessage.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No messages stored.");
    } else {
        StringBuilder messages = new StringBuilder("Stored Messages:\n");
        for (int i = 0; i < recentlySentMessage.size(); i++) {
            messages.append(recentlySentMessage.getElementAt(i)).append("\n");
        }
        JOptionPane.showMessageDialog(null, messages.toString());
    }
}
  
  
  
   // Method to display all discardedMessage
 private static void discardedMessage() {
    if (discardedMessage.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No messages discarded.");
    } else {
        StringBuilder messages = new StringBuilder("Discarded Messages:\n");
        for (int i = 0; i < discardedMessage.size(); i++) {
            messages.append(discardedMessage.getElementAt(i)).append("\n");
        }
        JOptionPane.showMessageDialog(null, messages.toString());
    }
} 
     // Method to display Longest Message
    private static void displayLongestMessage(String title, DefaultListModel<String> listModel) {
        if (listModel.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages to display.");
        } else {
            StringBuilder messages = new StringBuilder(title + ":\n");
            for (int i = 0; i < listModel.size(); i++) {
                messages.append(listModel.getElementAt(i)).append("\n");
            }
            JOptionPane.showMessageDialog(null, messages.toString());
        }
    }

     // Method to display search Message
    private static void searchMessage() {
    String recipientPhoneNumber = JOptionPane.showInputDialog("Enter recipient's phone number to search:");
    if (recipientPhoneNumber != null && !recipientPhoneNumber.isEmpty()) {
        StringBuilder result = new StringBuilder("Messages sent to " + recipientPhoneNumber + ":\n");
        boolean found = false;
        for (int i = 0; i < recentlySentMessage.size(); i++) {
            String message = recentlySentMessage.getElementAt(i);
            if (message.contains("Recipient:" + recipientPhoneNumber)) {
                result.append(message).append("\n");
                found = true;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(null, result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No messages found for this recipient.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "Please enter a recipient's phone number.");
    }
}

     // Method to display all delete Message
    private static void deleteMessage() {
        String messageId = JOptionPane.showInputDialog("Enter message ID to delete:");
        if (messageId != null && !messageId.isEmpty()) {
            for (int i = 0; i < sendMessage.size(); i++) {
                String message = sendMessage.getElementAt(i);
                if (message.contains("ID:" + messageId)) {
                    sendMessage.removeElementAt(i);
                    JOptionPane.showMessageDialog(null, "Message deleted.");
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Message ID not found.");
        }
    }

     // Method to display all display Longest Message
    private static void displayLongestMessage() {
        if (sendMessage.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent.");
        } else {
            String longestMessage = sendMessage.getElementAt(0);
            for (int i = 1; i < sendMessage.size(); i++) {
                String currentMessage = sendMessage.getElementAt(i);
                if (currentMessage.length() > longestMessage.length()) {
                    longestMessage = currentMessage;
                }
            }
            JOptionPane.showMessageDialog(null, "Longest Message:\n" + longestMessage);
        }
    }

     // Method to display all read JsonFile
    private static void readJsonFile() {
        String filePath = JOptionPane.showInputDialog("Enter JSON file path:");
        
    }    
            

    private static String generateMessageId() {
        String newId;
        do{
            int firstDigit =1 + random.nextInt(9);
            int remainingDigits = random.nextInt(1_000_000_000);
            newId = firstDigit + String.format("%09d",remainingDigits);
        }while (sendMessage.contains(newId));
        return newId;
    }
}  
       
       




    
   
    
    
    
 


    
       

    


    
    

